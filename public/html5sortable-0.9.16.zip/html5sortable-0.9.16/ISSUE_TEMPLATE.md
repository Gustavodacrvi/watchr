### I'm opening this issue because:

### supporting information:
- I use sortable version:
- I tested in the following browser (incl. versions):
- Windows, OS X/macOS, or Linux?:

### How can the issue be reproduce the problem?
Please add a complete description of how to reproduce the problem.

### Thank you for contributing!
- Please make sure your contribution is in line with the contribution guidelines: 
  https://github.com/lukasoppermann/html5sortable/blob/master/CONTRIBUTING.md

- Participation in this open source project is subject to the Code of Conduct:
  https://github.com/lukasoppermann/html5sortable/blob/master/CODE_OF_CONDUCT.md

Before creating a feature requests, please review the existing feature requests and make sure there isn't one that already describes the feature you are missing:
https://github.com/lukasoppermann/html5sortable/issues?q=is%3Aopen+is%3Aissue+label%3Afeature

#### What's the feature?

#### What problem is the feature intended to solve?

#### Is this feature similar to an existing feature in another project?
